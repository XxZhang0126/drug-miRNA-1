from sklearn import metrics
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, precision_score, recall_score, accuracy_score, f1_score, matthews_corrcoef, confusion_matrix

precision = []
recall = []

def calculate_metric(data):
    dataset = pd.DataFrame(data)
    y_test = dataset.iloc[:, 1]
    y_score = dataset.iloc[:, 2]
    y_score = np.around(y_score, 0).astype(int)
    acc = accuracy_score(y_test, y_score)
    precision = precision_score(y_test, y_score)
    recall = recall_score(y_test, y_score)
    fscore = f1_score(y_test, y_score)
    mcc = matthews_corrcoef(y_test, y_score)

    fpr, tpr, thresholds = roc_curve(y_test, y_score)
    auc = metrics.auc(fpr, tpr)

    # 计算敏感性（sensitivity）和特异性（specificity）
    tn, fp, fn, tp = confusion_matrix(y_test, y_score).ravel()
    sensitivity = tp / (tp + fn)
    specificity = tn / (tn + fp)
    
    return acc, precision, recall, fscore, mcc, sensitivity, specificity
