import pandas as pd

# 读取包含 miRNA-药物对的文件
associations_df = pd.read_csv('/home/xxzhang/jupyterlab/BNEMDI-main/Data/SM2miR3 MDIs.csv', header=None, delimiter=',')

# 获取唯一的药物和 miRNA 编号
unique_drugs = sorted(associations_df[0].unique())
unique_mirnas = sorted(associations_df[1].unique())

# 创建关联矩阵
association_matrix = pd.DataFrame(0, index=unique_drugs, columns=unique_mirnas)

# 填充关联矩阵
for _, row in associations_df.iterrows():
    drug, mirna = row[0], row[1]
    association_matrix.loc[drug, mirna] = 1

# 将关联矩阵保存为 CSV 文件
association_matrix.to_csv('/home/xxzhang/jupyterlab/BNEMDI-main/Data/matrix3.csv')
