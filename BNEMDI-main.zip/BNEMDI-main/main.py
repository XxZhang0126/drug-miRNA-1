import tensorflow.python.keras
from tensorflow.keras import layers
from tensorflow.python.keras import regularizers
from tensorflow.python.keras.models import Model
from tensorflow.python.keras import backend as K
from tensorflow.python.keras.callbacks import ReduceLROnPlateau
from tensorflow.python.keras.utils import np_utils
from tensorflow.keras.callbacks import EarlyStopping
import csv
import os
import pandas as pd
import numpy as np
import tensorflow as tf
#from tensorflow import keras
#from tensorflow.keras import layers
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Dense, Activation, Flatten
from metrics import calculate_metric
from roc import calculate_AUC
from sklearn.model_selection import StratifiedKFold,KFold
from sklearn.model_selection import StratifiedShuffleSplit


def GenerateAttributeFeature(InteractionPair, drug_feature, miRNA_feature):
    SampleFeature1 = []
    SampleFeature2 = []

    for i in range(len(InteractionPair)):
        Pair1 = str(InteractionPair[i][1])  #drug
        Pair2 = str(InteractionPair[i][0])  #mirna
        for m in range(len(drug_feature)):#drug
            if int(Pair1) == int(drug_feature[m][0]):
                SampleFeature1.append(drug_feature[m][1:])
                break
        for n in range(len(miRNA_feature)):#mirna
            if Pair2 == str(miRNA_feature[n][0]):
                SampleFeature2.append(miRNA_feature[n][1:])
                break

    SampleFeature1 = np.array(SampleFeature1).astype('float32')
    SampleFeature2 = np.array(SampleFeature2).astype('float32')

    return SampleFeature1, SampleFeature2


def MyLabel(Sample):
    label = []
    for i in range(int(len(Sample) / 2)):
        label.append(1)
    for i in range(int(len(Sample) / 2)):
        label.append(0)
    return label





if __name__ == '__main__':
    dataset_list = ['ncDR']
    for dataset in dataset_list:
        CounterT = 0

        
        while CounterT < 5:
            AllNodeBehavior = pd.read_csv(r'./Feature_topological/BiNE/data/ncDR/'+dataset+' BiNE 0.01 0.1.csv', header=None).values.tolist()
            AllBiLSTM_miRNA = pd.read_csv(r'Feature_attribute/'+dataset+' BiLSTM 64.csv', header=None).values.tolist()
            AllTCN_drug = pd.read_csv(r'Feature_attribute/'+dataset+' TCN 128.csv', header=None).values.tolist()
            
            PositiveSample_Train = pd.read_csv(os.path.join(dataset, 'data', 'PositiveSample_Train' + str(CounterT) + '.csv'), header=None).values.tolist()
            PositiveSample_Validation = pd.read_csv(os.path.join(dataset, 'data', 'PositiveSample_Validation' + str(CounterT) + '.csv'), header=None).values.tolist()
            PositiveSample_Test = pd.read_csv(os.path.join(dataset, 'data', 'PositiveSample_Test' + str(CounterT) + '.csv'), header=None).values.tolist()

            NegativeSample_Train = pd.read_csv(os.path.join(dataset, 'data', 'NegativeSample_Train' + str(CounterT) + '.csv'), header=None).values.tolist()
            NegativeSample_Validation = pd.read_csv(os.path.join(dataset, 'data', 'NegativeSample_Validation' + str(CounterT) + '.csv'), header=None).values.tolist()
            NegativeSample_Test = pd.read_csv(os.path.join(dataset, 'data', 'NegativeSample_Test' + str(CounterT) + '.csv'), header=None).values.tolist()
            
            
            x_train_pair = []
            x_train_pair.extend(PositiveSample_Train)
            x_train_pair.extend(NegativeSample_Train)

            x_validation_pair = []
            x_validation_pair.extend(PositiveSample_Validation)
            x_validation_pair.extend(NegativeSample_Validation)

            x_test_pair = []
            x_test_pair.extend(PositiveSample_Test)
            x_test_pair.extend(NegativeSample_Test)

            x_train_1_Attribute, x_train_2_Attribute = GenerateAttributeFeature(x_train_pair, AllTCN_drug,AllBiLSTM_miRNA)
            x_validation_1_Attribute, x_validation_2_Attribute = GenerateAttributeFeature(x_validation_pair,AllTCN_drug,AllBiLSTM_miRNA)
            x_test_1_Attribute, x_test_2_Attribute = GenerateAttributeFeature(x_test_pair, AllTCN_drug,AllBiLSTM_miRNA)

            x_train_1_Behavior = GenerateBehavior1Feature(x_train_pair, AllNodeBehavior)
            x_train_2_Behavior = GenerateBehavior2Feature(x_train_pair, AllNodeBehavior)
            x_validation_1_Behavior = GenerateBehavior1Feature(x_validation_pair, AllNodeBehavior)
            x_validation_2_Behavior = GenerateBehavior2Feature(x_validation_pair, AllNodeBehavior)
            x_test_1_Behavior = GenerateBehavior1Feature(x_test_pair, AllNodeBehavior)
            x_test_2_Behavior = GenerateBehavior2Feature(x_test_pair, AllNodeBehavior)

            num_classes = 2
            y_train_Pre = MyLabel(x_train_pair)     # Label->one hot
            y_validation_Pre = MyLabel(x_validation_pair)
            y_test_Pre = MyLabel(x_test_pair)

            y_train = np_utils.to_categorical(y_train_Pre, num_classes)
            y_validation = np_utils.to_categorical(y_validation_Pre, num_classes)
            y_test = np_utils.to_categorical(y_test_Pre, num_classes)
            input1 = Input(shape=(len(x_train_1_Attribute[0]),), name='input1')
            x1 = Dense(64, activation='relu', activity_regularizer=regularizers.l2(0.05))(input1)
            x1 = Dropout(rate=0.3)(x1)
        
            input2 = Input(shape=(len(x_train_2_Attribute[0]),), name='input2')
            x2 = Dense(64, activation='relu', activity_regularizer=regularizers.l2(0.05))(input2)
            x2 = Dropout(rate=0.3)(x2)

        
            input3 = Input(shape=(len(x_train_1_Behavior[0]),), name='input3')
            x3 = Dense(128, activation='relu', activity_regularizer=regularizers.l2(0.05))(input3)
            x3 = Dropout(rate=0.3)(x3)
        
            input4 = Input(shape=(len(x_train_2_Behavior[0]),), name='input4')
            x4 = Dense(128, activation='relu', activity_regularizer=regularizers.l2(0.05))(input4)
            x4 = Dropout(rate=0.3)(x4)
        


            miRNA_features = tf.keras.layers.concatenate([x2, x3])
            drug_features = tf.keras.layers.concatenate([x1, x4])


    
    
            miRNA_features = tf.expand_dims(miRNA_features,axis=2)

            mi_fe = Flatten()(miRNA_features)

            drug_features = tf.expand_dims(drug_features,axis=2)
            dr_fe = Flatten()(drug_features)
            
            flatten = tf.keras.layers.concatenate([mi_fe, dr_fe])
            hidden = Dense(32, activation='relu', name='hidden2', activity_regularizer=regularizers.l2(0.01))(flatten)
            hidden = Dropout(rate=0.3)(hidden)
            output = Dense(num_classes, activation='softmax', name='output')(hidden)
            model = Model(inputs=[input1, input2, input3, input4], outputs=output)
            model.summary()
            model.compile(optimizer='adam',
                          loss='binary_crossentropy',
                          metrics=['accuracy'])
        
            
            
            reduce_lr = ReduceLROnPlateau(monitor='val_accuracy', patience=5, mode='auto')  # Automatically adjust the learning rate
            history = model.fit({'input1': x_train_1_Attribute, 'input2': x_train_2_Attribute, 'input3': x_train_1_Behavior, 'input4':            x_train_2_Behavior},
                                 y_train,
                                 validation_data=({'input1': x_validation_1_Attribute, 'input2': x_validation_2_Attribute,
                                               'input3': x_validation_1_Behavior,  'input4': x_validation_2_Behavior}, y_validation),
                                 callbacks=[reduce_lr],
                                 epochs=50, batch_size=128 
                               )

            ModelTest = Model(inputs=model.input, outputs=model.get_layer('output').output)
            ModelTestOutput = ModelTest.predict([x_test_1_Attribute, x_test_2_Attribute, x_test_1_Behavior, x_test_2_Behavior]


            LabelPredictionProb = []
            LabelPrediction = []

            counter = 0
            while counter < len(ModelTestOutput):
                rowProb = []
                rowProb.append(y_test_Pre[counter])
                rowProb.append(ModelTestOutput[counter][1])
                LabelPredictionProb.append(rowProb)

                row = []
                row.append(y_test_Pre[counter])
                if ModelTestOutput[counter][1] > 0.5:
                    row.append(1)
                else:
                    row.append(0)
                LabelPrediction.append(row)

                counter = counter + 1
            
            
            pd.DataFrame(LabelPredictionProb).to_csv(dataset+'/Prediction Probability' + str(CounterT) + '.csv')
            pd.DataFrame(LabelPrediction).to_csv(dataset+'/Prediction result' + str(CounterT) + '.csv')

         
            accuracy,precision,recall,fscore,mcc,sensitivity,specificity,auc = calculate_metric(data)

            

            CounterT = CounterT + 1
                
